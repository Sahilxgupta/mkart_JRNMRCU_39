package com.mkart.dao;

public interface AdminDao {

}
