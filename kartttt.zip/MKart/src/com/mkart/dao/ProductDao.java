package com.mkart.dao;
import java.util.List;
import com.mkart.model.Products;

public interface ProductDao {
	
	void add(Products products);
	
	void update(Products products);
	
	Products getProduct(int productId);
	
	List<Products> getAllProducts();

}
