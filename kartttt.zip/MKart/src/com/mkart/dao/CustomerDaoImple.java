package com.mkart.dao;
import java.util.HashMap;
import java.util.Map;
import com.mkart.model.Customer;

public class CustomerDaoImple implements CustomerDao {

	private static Map<Integer,Customer> customers;
	private static Map<Integer,Integer> cartItems=new HashMap<Integer,Integer>(); 

	public CustomerDaoImple() {
		if (customers==null) {
			customers=new HashMap<>();
		}
	}
	@Override
	public boolean register(Customer customer) {
		int initSize=customers.size();
		customers.put(customer.getId(), customer);
		if(customers.size()>initSize) {
			return true;
		}
		else
		return false;
	}

	@Override
	public boolean addProduct(Customer customer,int productId) {
		cartItems.put(customer.getId(), productId);
		return true;
	}

	@Override
	public Integer showCart(Customer customer) {
		return cartItems.get(customer.getId());
	}
}
