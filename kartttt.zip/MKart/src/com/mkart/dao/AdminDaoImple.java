package com.mkart.dao;

public class AdminDaoImple implements AdminDao{	
}
