package com.mkart.dao;

import com.mkart.model.Customer;

public interface CustomerDao {
	
	public boolean register(Customer customer);
	
	public boolean addProduct(Customer customer,int productId);
	
	public Integer showCart(Customer customer);
}
