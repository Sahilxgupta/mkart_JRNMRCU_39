package com.mkart.dao;

import java.util.List;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.mkart.model.Products;

public class ProductDaoImple implements ProductDao {
public static Map<Integer,Products> mproducts;
	
	public ProductDaoImple() {
		if (mproducts==null) {
			mproducts=new HashMap<>();
		}
	}

	@Override
	public void add(Products products) {
		mproducts.put(products.getId(), products);
	}

	@Override
	public void update(Products products) {
		mproducts.replace(products.getId(),products);
	}

	@Override
	public Products getProduct(int productId) {
		return mproducts.get(productId);
	}

	@Override
	public List<Products> getAllProducts() {
		ArrayList<Products> arrList=new ArrayList<>();
		Collection<Products> productsList=mproducts.values();
		for(Products p :productsList) {
			arrList.add(p);
		}
		return arrList;
	}
}
