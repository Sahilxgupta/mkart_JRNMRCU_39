package com.mkart.model;

import java.util.ArrayList;

public class Cart {
	
	private int cartId;
	private ArrayList<Products> products;
	
	public Cart(){
	}
	
	public Cart(int cartId, ArrayList<Products> products) {
		super();
		this.cartId=cartId;
		this.products=products;
	}

	public ArrayList<Products> getProducts() {
		return products;
	}

	public void setProducts(ArrayList<Products> products) {
		this.products = products;
	}

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	
	@Override
	public String toString() {
		return "Cart id:"+cartId+",products:"+products;
	}
}
