package com.mkart.service;
import com.mkart.model.Customer;

public interface CustomerService {
	
	boolean register(Customer customer);
	
	Integer showCart(Customer customer);

	Customer addProduct(Customer customer, int productId);
	
}
