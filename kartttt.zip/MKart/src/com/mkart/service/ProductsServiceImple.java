package com.mkart.service;

import java.util.List;
import com.mkart.dao.ProductDao;
import com.mkart.dao.ProductDaoImple;
import com.mkart.model.Products;

public class ProductsServiceImple implements ProductsService {
private static ProductDao productDao;

	public ProductsServiceImple() {
		if(productDao==null)
						productDao=new ProductDaoImple();
	}

	@Override
	public boolean add(Products products) {
		productDao.add(products);
		Products savedProduct = productDao.getProduct(products.getId());

		if (savedProduct != null)
			return true;
		else
			return false;

	}
	@Override
	public void update(Products products) {
		productDao.update(products);
	}

	@Override
	public Products getProduct(int productId) {
		return productDao.getProduct(productId);
	}

	@Override
	public List<Products> getAllProducts() {
		return productDao.getAllProducts();
	}
}
