package com.mkart.service;

import com.mkart.dao.CustomerDao;
import com.mkart.model.Customer;
import com.mkart.dao.CustomerDaoImple;

public class CustomerServiceImple implements CustomerService {

	private static CustomerDao customerDao;
	public CustomerServiceImple() {
		if(customerDao==null) {
			customerDao=new CustomerDaoImple();
		}
	}
	
	@Override
	public boolean register(Customer customer) {
		customerDao.register(customer);	
		return true;
	}

	@Override
	public Customer addProduct(Customer customer,int productId) {
		customerDao.addProduct(customer,productId);
		return customer;
	}

	@Override
	public Integer showCart(Customer customer) {
		return customerDao.showCart(customer);
	}	
	
}
