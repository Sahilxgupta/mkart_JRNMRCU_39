package com.mkart.service;

import java.util.List;
import com.mkart.model.Products;

public interface ProductsService {
	
	boolean add(Products product);

	void update(Products product);

	Products getProduct(int productId);

	List<Products> getAllProducts();

}
