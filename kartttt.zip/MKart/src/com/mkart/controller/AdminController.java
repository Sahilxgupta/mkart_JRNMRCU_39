package com.mkart.controller;
import java.util.List;
import java.util.Scanner;

import com.mkart.util.InputUtil;
import com.mkart.model.Products;
import com.mkart.service.ProductsService;
import com.mkart.service.ProductsServiceImple;

public class AdminController {

	private static ProductsService productService;

	public AdminController() {

		if (null == productService) {
			productService = new ProductsServiceImple();
		}
	}
	
	public void operations() {
	Scanner scanner = InputUtil.getScanner();
	boolean status = true;
	while (status) {
		System.out.println("1. Add Product \n 2.Update Product \n 3.View Product \n 4.View All Products \n 5.Exit");
		System.out.println("Enter the choice:");
		int choice = scanner.nextInt();

		switch (choice) {

		case 1:
			System.out.println("enter product id, name,price: ");
			int id = scanner.nextInt();
			String name = scanner.next();
			int price = scanner.nextInt();

			Products p = new Products();
			p.setId(id);
			p.setName(name);
			p.setPrice(price);

			if (productService.add(p)) {
				System.out.println("Product added successfully.");
			} else {
				System.out.println("Product not added.");
			}
			break;

		case 2:
			break;

		case 3:
			System.out.println("enter product id:");
			id = scanner.nextInt();
			Products products = productService.getProduct(id);
			System.out.println(products);
			break;
		case 4:
			List<Products> allProducts = productService.getAllProducts();

			for (Products prod : allProducts) {
				System.out.println(prod);
			}
			break;
		case 5:
			System.out.println("Exiting admin operations..!");
			status = false;
		}

	}
	
	}
}
