package com.mkart.controller;

import java.util.Scanner;
import com.mkart.util.InputUtil;
import com.mkart.model.Customer;
import com.mkart.service.CustomerService;
import com.mkart.service.CustomerServiceImple;

public class CustomerController {
	private static CustomerService customerService;

	public CustomerController() {

		if(customerService==null) {
			customerService =new CustomerServiceImple();
		}
	}
	
	public void operations() {
		Scanner scanner = InputUtil.getScanner();
		boolean status=true;
		while (status) {
			System.out.println("1.Register Customer \n 2.Add Product to Cart \n 3.View Products in Cart \n 4.Exit");
			System.out.println("Enter the choice:");
			
			int choice = scanner.nextInt();

			switch (choice) {

			case 1:
				System.out.println("enter customer id, name, email, phone: ");
				int id = scanner.nextInt();
				String name = scanner.next();
				String email=scanner.next();
				int phone=scanner.nextInt();

				Customer c=new Customer();
				c.setId(id);
				c.setName(name);
				c.setEmail(email);
				c.setPhone(phone);
				if (customerService.register(c)) {
					System.out.println("Customer registered successfully.");
				} else {
					System.out.println("Customer not registered.");
				}
				break;
			case 2:
				System.out.println("enter customer id, name, email, phone: ");
				int id1 = scanner.nextInt();
				String name1 = scanner.next();
				String email1=scanner.next();
				int phone1=scanner.nextInt();

				Customer c1=new Customer();
				c1.setId(id1);
				c1.setName(name1);
				c1.setEmail(email1);
				c1.setPhone(phone1);
				System.out.println("enter product id:");
				id = scanner.nextInt();
				Customer customer= customerService.addProduct(c1, id);
				System.out.println(customer);
				break;
			case 3:
				System.out.println("enter customer id, name, email, phone: ");
				int id2 = scanner.nextInt();
				String name2 = scanner.next();
				String email2=scanner.next();
				int phone2=scanner.nextInt();

				Customer c2=new Customer();
				c2.setId(id2);
				c2.setName(name2);
				c2.setEmail(email2);
				c2.setPhone(phone2);
				Integer cartProducts =customerService.showCart(c2);
				System.out.println(cartProducts);
				break;			
			case 4:
				System.out.println("Exiting customer operations..");
				status=false;
		}
	}	
  }
}
